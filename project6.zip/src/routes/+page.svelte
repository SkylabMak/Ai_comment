<script lang="ts">
import Homepage from '../components/Homepage.svelte';
</script>
<div>
    <Homepage />
</div>

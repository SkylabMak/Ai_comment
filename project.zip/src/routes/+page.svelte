<script lang="ts">
import Homepage from '../components/Homepage.svelte';
export let data;
const pageData = data.data as Alldata;
const dataWithType = pageData
</script>

<Homepage data={pageData}/>